File Name:Ransom.BloodySKULL.exe
Version:1.0.0
Category:Malware/horror

this is a Ransomware.

Please Run "Ransom.BloodySKULL.exe".
Don't Run "MBR.exe".

!WARNING!
This program is harmful to your computer.
Never run it on a real machine!
Also, this program is for educational and research purposes!
Never, never, never use to malicious!
Use a virtual machine to run this, and do so at your own risk.

Created by hamutan.
Contact: hamutan#3859
